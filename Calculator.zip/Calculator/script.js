let display = document.getElementById('display');
let expression = '';


function numberFunction(number){
    expression = expression + number;
    display.value = expression;
}



function operatorFunction(operator){
    expression = expression + operator;
    display.value = expression;
}


function result(){
    var result = eval(expression);
    display.value = result;
}


function allClear(){
    expression= '' ;
    display.value= '';
}
